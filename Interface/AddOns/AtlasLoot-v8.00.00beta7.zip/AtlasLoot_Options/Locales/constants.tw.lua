﻿local AL = _G.AtlasLoot.GetLocales("zhTW")

if not AL then return end

-- These localization strings are translated on WoWAce: http://www.wowace.com/addons/atlasloot-enhanced/localization
AL["AtlasLoot Options"] = "AtlasLoot 選項"


