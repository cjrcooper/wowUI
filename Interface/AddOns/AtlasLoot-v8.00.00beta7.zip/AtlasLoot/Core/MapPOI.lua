local AtlasLoot = _G.AtlasLoot
local MapPOI = {}
AtlasLoot.MapPOI = MapPOI

