local AtlasLoot = _G.AtlasLoot
local Token = {}
AtlasLoot.Data.Token = Token
local AL = AtlasLoot.Locales

local TOKEN = {
	["token"] = {	-- Normal tokens
		
	},
	["multitoken"] = {	-- Tokens that can used for purchase other tokens a Token token! ( for example garrosh token ) 
		
	}
}